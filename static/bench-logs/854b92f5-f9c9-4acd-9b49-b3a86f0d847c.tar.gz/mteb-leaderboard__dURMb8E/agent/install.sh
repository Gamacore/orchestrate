apt-get update
apt-get install -y curl git coreutils
command -v nohup >/dev/null 2>&1 || (echo "nohup not found" && exit 1)

# Note that we use uv instead of pip because there's a task,
# broken-python, that intentionally breaks pip.
# Some tasks also override /root
curl -LsSf https://astral.sh/uv/install.sh | env UV_INSTALL_DIR="/uv" sh
source /uv/env
export UV_PYTHON_INSTALL_DIR=/uv/python
export UV_CACHE_DIR=/uv/cache

uv venv /uv/forge --python 3.13
source /uv/forge/bin/activate
uv pip install openai pydantic

# Ensure Python is discoverable in non-login/non-activated shells used by agents
ln -sf /uv/forge/bin/python /usr/local/bin/python
ln -sf /uv/forge/bin/python /usr/local/bin/python3

# Forge binary is uploaded by harbor's setup process
# Just ensure it's executable
chmod +x /usr/local/bin/forge

# Verify forge is installed
/usr/local/bin/forge --version || echo "Forge installed (version check may not be supported)"